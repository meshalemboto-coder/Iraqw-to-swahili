# Kamusi ya Kiiraqw — binafsi

Programu ya Android ya kutafuta Kiiraqw ↔ Kiswahili bila intaneti. Inajumuisha maneno ya mwanzo yaliyopatikana kwenye nyenzo za Nukta Kamusi pamoja na maneno matatu yaliyotolewa na mtumiaji (Laway, Lawlar, I sayu).

**Tahadhari:** Chanzo cha kamusi kinaeleza kuwa baadhi ya data ni ya majaribio. Maneno, maana na matamshi yanahitaji kuhakikiwa na mzungumzaji wa Kiiraqw wa Mbulu/Babati. Matamshi ndani ya app ni mwongozo wa kusoma, si sauti iliyorekodiwa.

## Kujenga APK kwa simu kupitia GitHub

Hii ni mradi wa chanzo, si APK iliyojengwa tayari. Workflow ya GitHub Actions imewekwa ili ijenge APK kwenye cloud bila kuhitaji Android Studio kwenye simu.

1. Fungua GitHub kwenye browser ya simu na ingia/unda akaunti.
2. Unda repository mpya, mfano `kamusi-kiiraqw`.
3. Pakia **maudhui yote ya ZIP hii** kwenye repository, pamoja na folda iliyofichwa `.github/workflows/build-apk.yml`. Ni rahisi zaidi kufanya upload ya mafaili kupitia GitHub web; hakikisha `.github/workflows/build-apk.yml` ipo.
4. Baada ya mafaili kuingia, fungua tab ya **Actions** kwenye repository.
5. Chagua **Build personal APK** kisha **Run workflow** (au subiri build ianze baada ya push).
6. Fungua run iliyokamilika, shuka hadi **Artifacts**, pakua `Kamusi-Kiiraqw-APK.zip`.
7. Fungua ZIP hiyo kwenye simu; utapata `app-debug.apk`. Gusa APK kuisakinisha. Android inaweza kukuomba uruhusu **Install unknown apps** kwa browser au file manager unayotumia.

## Kujenga kwenye kompyuta

Fungua mradi huu kwa Android Studio, kisha Build > Build APK(s). Kwa kawaida APK itakuwa `app/build/outputs/apk/debug/app-debug.apk`.

## Data

Msamiati uko `app/src/main/assets/dictionary.json`. Rekodi zina sehemu `kiiraqw`, `swahili`, `notes`, `verified`. Kwa sasa `verified` inaashiria kuwa rekodi imeingizwa kutoka kwenye chanzo kilichotajwa au mtumiaji; **haimaanishi kuwa imethibitishwa kikamilifu na mtaalamu**. Hakiki tafsiri kabla ya kuitegemea.
